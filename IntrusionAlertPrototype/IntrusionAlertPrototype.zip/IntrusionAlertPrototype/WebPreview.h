#pragma once
#include <stdint.h>
#include "IntrusionLogic.h"
// 以 queue 複製此結構，不讓網路任務直接讀寫狀態機。
struct WebStatus {
    char state[12];
    uint32_t publishedMs, frameMs, sequence, events;
    uint32_t durationMs, startedMs;
    bool durationUncertain;
    unsigned historyCount;
    IntrusionRecord history[HISTORY_SIZE];
    int persons;
    unsigned insidePersons, peakPersons;
    bool haveFrame, warning, ledOn, truncated;
};
bool startWebPreview();
void publishWebStatus(const WebStatus &status);
// 保存確認入侵時最近的 JPEG；回傳 false 表示未取得照片，不以舊照片替代。
bool saveEventPhoto(uint32_t event, uint32_t enteredMs);
