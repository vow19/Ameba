#pragma once
#include <stdint.h>
#include "AlertConfig.h"
// 時間差以 32 位開機計時處理；同時限制目前影像年齡及相對事件的偏差。
inline bool usableEventPhoto(unsigned length, uint32_t imageMs, uint32_t eventMs, uint32_t now) {
    const int32_t offset = (int32_t)(imageMs-eventMs);
    return length > 4 && length <= AlertConfig::JPEG_CAPACITY &&
        uint32_t(now-imageMs) <= AlertConfig::EVENT_PHOTO_MAX_AGE_MS &&
        offset >= -(int32_t)AlertConfig::EVENT_PHOTO_MAX_AGE_MS &&
        offset <= (int32_t)AlertConfig::EVENT_PHOTO_MAX_AGE_MS;
}
inline bool eventPhotoSequenceReady(uint32_t current, uint32_t captureAfter) {
    return int32_t(current-captureAfter) > 0;
}
inline bool eventPhotoWaitExpired(uint32_t now, uint32_t requestedMs) {
    return uint32_t(now-requestedMs) > AlertConfig::EVENT_PHOTO_WAIT_MS;
}
