// 執行嵌入網頁的原始 JavaScript；模擬 DOM/時鐘/HTTP，不宣稱瀏覽器實測。
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../WebPage.h'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const nodes={};let clock=10000;let intervals=[];let revoked=[];
function element(){return {style:{},children:[],_text:'',src:'',get textContent(){return this._text+this.children.map(c=>c.textContent).join('');},set textContent(v){this._text=v;this.children=[];},appendChild(c){this.children.push(c);},replaceChildren(){this._text='';this.children=[];}};}
let started=0,stopped=0;
class AudioMock{
 constructor(){this.state='suspended';this.destination={};}
 resume(){return Promise.resolve();}
 createOscillator(){return {frequency:{value:0},connect(){},disconnect(){},start(){started++;},stop(){stopped++;}};}
 createGain(){return {gain:{value:0},connect(){},disconnect(){}};}
}
const context={
 window:{AudioContext:AudioMock,addEventListener(){}},
 document:{addEventListener(){},createElement:element,getElementById(id){return nodes[id]||(nodes[id]=element());}},
 performance:{now:()=>clock},Date,URL:{createObjectURL:()=> 'blob:test',revokeObjectURL:u=>revoked.push(u)},
 setTimeout,clearTimeout,setInterval:f=>intervals.push(f),AbortController,
 fetch:async()=>{throw Error('offline');},
 Image:class{set src(v){this.onload();}}
};
vm.createContext(context);vm.runInContext(source,context);
(async()=>{
 await new Promise(r=>setTimeout(r,10));
 vm.runInContext('render()',context);assert.equal(nodes.state.textContent,'監測異常');assert(nodes.cover.style.display==='grid');
 vm.runInContext("data={state:'SAFE',events:2,persons:0,sequence:9,warning:false,led_on:false,truncated:false};lastStatus=performance.now();lastImage=performance.now();render()",context);
 assert.equal(nodes.state.textContent,'SAFE');assert.equal(nodes.cover.style.display,'none');
 clock+=3100;vm.runInContext('render()',context);assert(nodes.state.textContent!=='SAFE');
 vm.runInContext("lastStatus=performance.now();lastImage=0;render()",context);assert(nodes.state.textContent!=='SAFE');
 vm.runInContext("lastImage=performance.now();data.state='STALE';render()",context);assert.equal(nodes.cover.style.display,'grid');
 vm.runInContext("data.state='WARNING';data.warning=true;data.led_on=true;render()",context);assert.equal(nodes.state.textContent,'WARNING');
 nodes.toggle.onclick();assert.equal(nodes.toggle.textContent,'恢復影像');assert(nodes.state.textContent!=='SAFE');
 console.log('PASS: initial offline, fresh SAFE, expired status, expired image, STALE, WARNING, pause (7 scenarios)');
 vm.runInContext("running=true;data={state:'WARNING',warning:true,duration_ms:1234};lastStatus=performance.now();checkAlarm()",context);
 assert.equal(started,0); // Browser initially blocks autoplay.
 vm.runInContext("audio.state='running';checkAlarm();checkAlarm()",context);
 assert.equal(started,2);assert.equal(stopped,0); // One oscillator pair, not one per poll.
 vm.runInContext("data.state='SAFE';data.warning=false;checkAlarm()",context);assert.equal(stopped,2);
 vm.runInContext("data.state='WARNING';data.warning=true;checkAlarm()",context);assert.equal(started,4);
 nodes.sound.onclick();assert.equal(stopped,4);
 vm.runInContext("checkAlarm()",context);assert.equal(started,4);
 nodes.sound.onclick();await Promise.resolve();assert.equal(started,6);
 clock+=3100;vm.runInContext('checkAlarm()',context);assert.equal(stopped,6);
 vm.runInContext("lastStatus=performance.now();data.state='STALE';checkAlarm()",context);assert.equal(started,6);
 vm.runInContext("data.state='WARNING';checkAlarm();running=false;checkAlarm();render()",context);assert.equal(started,8);assert.equal(stopped,8);
 assert.equal(nodes.duration.textContent,'1.2');
 console.log('PASS: autoplay blocked, continuous warning, no overlap, SAFE stop, mute/unmute, stale/offline/pause stop');
 vm.runInContext("clockAnchor={uptime:10000,wall:Date.UTC(2026,9,22,10,0,10)};renderHistory('event,start,end,seconds,gap,status,peak_persons\\n1,200,2100,147.900,0,completed,2\\n2,3000,,0.500,1,active,3\\n')",context);
 assert(nodes.history.textContent.startsWith('002'));
 assert(nodes.history.textContent.includes('2分27秒'));
 assert(nodes.history.textContent.includes('＊'));
 assert.equal(nodes.history.children[0].children[3].textContent,'3');
 assert(nodes.history.children[0].children[1].title.includes('2026'));
 assert.notEqual(nodes.lastEntry.textContent,'—');
 vm.runInContext("running=true;data.inside_persons=2;data.persons=9;lastStatus=lastImage=performance.now();render()",context);
 assert.equal(nodes.persons.textContent,2);
 const many='header\n'+Array.from({length:32},(_,i)=>`${i+1},200,2100,1.9,0,completed,1`).join('\n');
 context.csvMany=many;vm.runInContext('renderHistory(csvMany)',context);assert.equal(nodes.history.children.length,10);
 vm.runInContext("renderHistory('event,start,end,seconds,gap,status\\n')",context);
 assert.equal(nodes.history.textContent,'尚無入侵紀錄');
 console.log('PASS: history newest first, duration, uncertainty and empty history');
 context.dark=Array.from({length:32*18*4},(_,i)=>i%4===3?255:0);
 context.texture=Array.from({length:32*18*4},(_,i)=>i%4===3?255:(Math.floor(i/4)%2?200:60));
 vm.runInContext('resetHealth();for(let t=1000;t<=6000;t+=1000)analyzePixels(dark,t)',context);
 assert(vm.runInContext('healthReason',context).includes('遮擋'));
 vm.runInContext('analyzePixels(texture,7000)',context);
 vm.runInContext('analyzePixels(texture.map((v,i)=>i%4===3?v:255-v),8000);analyzePixels(texture,9000)',context);
 assert.equal(vm.runInContext('healthReason',context),'');
 vm.runInContext('resetHealth();for(let t=1000;t<=33000;t+=1000)analyzePixels(texture,t)',context);
 assert(vm.runInContext('healthReason',context).includes('凍結'));
 vm.runInContext("resetHealth();running=true;data={state:'SAFE',sequence:7,uptime_ms:1000,frame_age_ms:0,image_age_ms:0};lastImage=lastStatus=performance.now();observeStatus()",context);
 clock+=3100;
 vm.runInContext('lastImage=lastStatus=performance.now();render()',context);
 assert.equal(nodes.state.textContent,'監測異常');assert(nodes.cover.textContent.includes('推論序號'));
 vm.runInContext('data.sequence++;observeStatus();data.image_age_ms=4000;render()',context);
 assert.equal(nodes.state.textContent,'監測異常');assert(nodes.cover.textContent.includes('JPEG'));
 vm.runInContext("renderPhotos([{event:3,entered_ms:1000,image_ms:1900,offset_ms:900,bytes:100,status:'ready'},{event:4,entered_ms:2000,image_ms:0,offset_ms:0,bytes:0,status:'pending'},{event:5,entered_ms:3000,image_ms:0,offset_ms:0,bytes:0,status:'failed'}])",context);
 assert.equal(nodes.photos.children.length,3);
 assert(nodes.photos.children[0].textContent.includes('逾時'));
 assert(nodes.photos.children[1].textContent.includes('等待'));
 assert.equal(nodes.photos.children[2].children[3].href,'/event/3-1000.jpg');
 console.log('PASS: obstruction heuristic, recovery, frozen content, inference heartbeat, JPEG age, photo mapping and failure');
})().catch(e=>{console.error(e);process.exitCode=1;});
