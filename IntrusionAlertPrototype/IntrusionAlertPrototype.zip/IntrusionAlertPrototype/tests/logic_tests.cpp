#include <assert.h>
#include <stdio.h>
#include "../IntrusionLogic.h"
#include "../EventPhotoPolicy.h"

static unsigned passed = 0;
#define CASE(name) printf("PASS: %s\n", name); ++passed
static uint32_t seq = 0;
static bool frame(IntrusionLogic &a, uint32_t t, bool inside, bool expanded) {
    return a.update(++seq,t,inside,expanded);
}
static void enter(IntrusionLogic &a, uint32_t t) {
    assert(!frame(a,t,true,true));
    assert(!frame(a,t+100,true,true));
    assert(frame(a,t+200,true,true));
    assert(a.warning);
}
static void leave(IntrusionLogic &a, uint32_t t) {
    for (uint32_t dt=0; dt<=1500; dt+=100) frame(a,t+dt,false,false);
    assert(!a.warning);
}
int main() {
    {
        assert(usableEventPhoto(100,1000,1500,1600));
        assert(!usableEventPhoto(100,1000,1500,2600));
        assert(!usableEventPhoto(100,4000,2000,4000));
        assert(!usableEventPhoto(0,1000,1500,1600));
        assert(!usableEventPhoto(AlertConfig::JPEG_CAPACITY+1,1000,1500,1600));
        assert(usableEventPhoto(100,UINT32_MAX-100,50,100));
        assert(!eventPhotoSequenceReady(11,11));
        assert(eventPhotoSequenceReady(12,11));
        assert(eventPhotoSequenceReady(0,UINT32_MAX));
        assert(!eventPhotoWaitExpired(3000,0));
        assert(eventPhotoWaitExpired(3001,0));
        CASE("event photo freshness, bounds and millis wrap");
    }
    {
        IntrusionLogic a;
        a.update(1,0,true,true,1);a.update(2,100,true,true,1);a.update(3,200,true,true,2);
        a.update(4,300,true,true,3);a.update(5,400,true,true,1);
        assert(a.peakPersons==3);
        for(uint32_t i=0;i<=15;++i)a.update(6+i,500+i*100,false,false,0);
        assert(a.historyCount==1 && a.history[0].peakPersons==3);
        a.update(22,2200,true,true,1);a.update(23,2300,true,true,1);a.update(24,2400,true,true,1);
        assert(a.peakPersons==1);
        CASE("per-event peak zone occupancy retained and reset");
    }
    {
        IntrusionLogic a; enter(a,0); frame(a,500,true,true);
        assert(a.durationMs==300); leave(a,600);
        assert(a.historyCount==1 && a.history[0].durationMs==1900);
        assert(a.history[0].startMs==200 && a.history[0].endMs==2100);
        enter(a,2300); assert(a.durationMs==0);
        frame(a,4000,true,true); assert(a.durationMs==0 && a.durationUncertain);
        leave(a,4100); assert(a.historyCount==2 && a.history[1].uncertain);
        CASE("duration reset, finalized history and inference gap");
    }
    {
        IntrusionLogic a;
        for(unsigned i=0;i<35;++i){enter(a,i*3000);leave(a,i*3000+300);}
        assert(a.historyCount==32 && a.history[0].event==4 && a.history[31].event==35);
        CASE("bounded history evicts oldest event");
    }
    {
        IntrusionLogic a;
        assert(!a.warning && a.events==0 && a.stale(0));
        frame(a,0,false,false); assert(!a.stale(0) && !a.warning && a.events==0);
        CASE("startup unknown then empty frame SAFE");
    }
    PersonBox in={.4f,.1f,.6f,.8f,80};
    PersonBox outside={.01f,.1f,.15f,.8f,80};
    assert(footInRoi(in) && !footInRoi(outside));
    PersonBox low=in; low.score=49; assert(!footInRoi(low));
    low.score=50; assert(footInRoi(low)); CASE("confidence and bottom center");
    {
        PersonBox edge={.2f,.1f,.4f,AlertConfig::ROI_TOP,80};
        assert(footInRoi(edge));
        edge.ymax=AlertConfig::ROI_BOTTOM; assert(footInRoi(edge));
        edge.ymax+=.001f; assert(!footInRoi(edge));
        assert(footInRoi(edge,AlertConfig::EXIT_MARGIN)); CASE("inclusive ROI boundary and exit margin");
    }
    {
        PersonBox b=in; b.xmax=NAN; assert(!footInRoi(b));
        b=in; b.ymin=b.ymax; assert(!footInRoi(b));
        b=in; b.xmin=-.1f; assert(!footInRoi(b)); CASE("invalid coordinates rejected");
    }
    {
        IntrusionLogic a;
        for(int i=0;i<30;++i)frame(a,i*100,footInRoi(outside),false);
        assert(a.events==0 && !a.warning); CASE("person outside never triggers");
    }
    {
        IntrusionLogic a;
        frame(a,0,true,true); frame(a,100,false,false); frame(a,200,true,true);
        assert(!a.warning && a.events==0); CASE("single frame false positive rejected");
    }
    {
        IntrusionLogic a;
        a.update(10,0,true,true);
        for(int i=0;i<100;++i)a.update(10,200,true,true);
        assert(!a.warning && a.events==0); CASE("duplicate inference never confirms");
    }
    {
        IntrusionLogic a;
        frame(a,0,true,true);frame(a,1,true,true);frame(a,2,true,true);
        assert(!a.warning);frame(a,200,true,true);assert(a.warning);
        CASE("minimum duration as well as frame count");
    }
    {
        IntrusionLogic a; enter(a,0);
        for(int i=3;i<100;++i)frame(a,i*100,true,true);
        assert(a.events==1); CASE("continuous presence counts once");
        leave(a,10000); enter(a,12000); assert(a.events==2); CASE("confirmed exit then reentry counts again");
    }
    {
        IntrusionLogic a; enter(a,0);
        frame(a,300,false,false);frame(a,400,false,false);frame(a,500,true,true);
        assert(a.warning && a.events==1); CASE("brief miss retains warning and count");
        for(int i=6;i<30;++i)frame(a,i*100,false,true);
        assert(a.warning && a.events==1); CASE("boundary jitter held by expanded ROI");
    }
    {
        IntrusionLogic a; enter(a,0);
        a.tick(5000); assert(a.stale(5000) && a.warning && a.events==1);
        frame(a,5100,true,true); assert(!a.stale(5100) && a.events==1);
        CASE("stale data does not release or recount");
        frame(a,5200,false,false); frame(a,8000,false,false);
        assert(a.warning); leave(a,8100); CASE("gap cannot satisfy exit dwell");
    }
    {
        IntrusionLogic a;
        frame(a,0,true,true);frame(a,100,true,true);frame(a,2000,true,true);
        assert(!a.warning);frame(a,2100,true,true);assert(!a.warning);frame(a,2200,true,true);assert(a.warning);
        CASE("gap resets entry confirmation");
    }
    {
        IntrusionLogic a;
        PersonBox boxes[]={outside,in,outside}; bool hit=false;
        for(auto &b:boxes)hit=hit||footInRoi(b);
        frame(a,0,hit,hit);frame(a,100,hit,hit);frame(a,200,hit,hit);
        assert(a.warning&&a.events==1);
        frame(a,300,true,true);assert(a.events==1); CASE("multiple people are one occupied-region event");
    }
    {
        IntrusionLogic a; uint32_t t=UINT32_MAX-150;
        enter(a,t); assert(a.events==1 && !a.stale(t+250));
        leave(a,t+400); assert(!a.warning); CASE("millis wraparound");
    }
    {
        IntrusionLogic a; a.update(UINT32_MAX-1,0,true,true);
        a.update(UINT32_MAX,100,true,true);a.update(0,200,true,true);
        assert(a.warning);a.update(UINT32_MAX,300,false,false);assert(a.lastSequence==0);
        CASE("sequence wrap and old result ignored");
    }
    printf("TOTAL %u cases passed\n",passed);
}
