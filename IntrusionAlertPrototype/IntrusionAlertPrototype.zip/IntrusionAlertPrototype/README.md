# 危險區域入侵提醒器：整合原型

## 2026-10-22：聲音、停留時間與 CSV

新增功能已完成程式修改；本節優先於下方舊版紀錄。尚未燒錄或驗證新增功能的實機效果。

- 網頁按「啟用警報聲」會播放測試音。此後每次新事件播放三聲短音，持續停留不重複播放；請保持網頁開啟及電腦音量可聽。VLC 本身不播放此警報。網路中斷時電腦無法即時警報，重連不會逐筆補播所有歷史事件。
- 網頁、RTSP 畫面底部與 Serial 顯示本次／最近一次停留秒數。從確認 WARNING 起算，確認離開結束，包含離開防抖時間。這是區域佔用時間，不是個別人物追蹤時間。等待新推論時數字不自行增加。
- 板子保存最近 32 次完成事件及目前進行中事件，網頁關閉也繼續記錄；下載歷史 CSV 可保存到電腦。超過容量會淘汰最舊事件，重開機清除，需自行定期下載，不會自動寫入電腦檔案。
- CSV 欄位：event（事件編號）、start_uptime_ms / end_uptime_ms（開機後毫秒，非日期時間）、duration_seconds（秒）、inference_gap（1 表示推論中斷，秒數不完整）、status（completed / active）。進行中事件結束時間留空。計時以有效連續推論為準，長中斷不累加；開機毫秒約 49.7 天會回繞。

修改位置：IntrusionLogic.h 負責計時與固定容量歷史；IntrusionAlertPrototype.ino 將時間輸出到 OSD/Serial 並傳給網頁任務；WebPreview.h/.cpp 增加狀態欄位及 /history.csv；WebPage.h 加入聲音按鈕、秒數與下載連結。未修改手勢專案或全域 SDK。

驗證步驟：燒錄後開啟當次 WEB URL，點啟用聲音，進入 ROI 並停留約 5 秒，確認只響一次且秒數增加；離開並等待 SAFE，確認秒數停止。再進入一次，確認秒數重算、再次響聲。下載 CSV 核對兩筆事件；測試短暫漏偵測不拆成兩筆。秒數包含進出確認延遲，因此不會精確等於手持碼錶時間。

自動驗證：20 項 C++ 邏輯案例通過，含時間結算、重進歸零、推論中斷與歷史容量；網頁原有 7 個情境及新增事件去重、過期抑制、重啟基準與秒數顯示測試通過。實際喇叭發聲、CSV 下載及跨通道 OSD 仍待實機測試。

## 目前狀態（2026-10-18）

已在獨立的 `IntrusionAlertPrototype` 專案整合人物偵測、可調整 ROI、底部中心點判斷、連續影格防抖、入侵事件計數、離開確認、LED/OSD/Serial 輸出，以及 HTTP 即時狀態與 JPEG 快照網頁；RTSP 仍保留。原手勢專案未修改。

最新整合版於 01:32:11–01:32:24 使用 portable AmebaPro2 4.0.9 編譯成功；18 項桌面邏輯測試及 7 個網頁狀態情境通過。01:34 已透過 COM4 成功燒錄；韌體 SHA-256 為 `EB97A6B735F5C7679A46E7E60C56AEFEC50B14A458121B0A42CA87F5BE9B21FD`。01:39 的 Serial 輸出已確認推論序號持續增加、人物偵測結果有 0/1 變化，並輸出 `STATE=SAFE`、`inside=0`、`events=0`；這代表當時人物底部中心點尚未進入 ROI，符合未觸發狀態。使用者確認 VLC 串流與黃色 `DANGER ZONE` ROI 框正常，並實測人物進入 ROI 後出現 WARNING、`events=1` 且 LED 亮。RTSP、ROI OSD、入侵觸發及 LED 警示已初步實機確認。**重複觸發抑制、離開後解除/重進、網頁 JPEG 與 RTSP 長時間穩定性仍待驗證**。曾出現一次 `hal_voe_send2voe too long`，後續推論仍持續；需觀察是否反覆發生。先前 00:30 的成功燒錄是 Phase 2 人物偵測版，不含目前的 ROI、事件警示與網頁整合。最新候選版與燒錄紀錄見 `BUILD_VERIFICATION.json`、`UPLOAD_VERIFICATION.json`。

下一步先確認網頁及影像 URL，再用畫面中的 ROI 測試進入、持續停留與離開/重進；同時核對 `inside`、SAFE/WARNING、事件數和 LED。實機結果須另行記錄，不以編譯或燒錄成功推定。

尺寸修正：SDK 雖定義 VIDEO_WVGA，四參數建構函式未處理此值。現在使用 `VideoSetting(640, 360, 15, VIDEO_H264, 0)`，並印出 `VIDEO_CONFIG: 640x360 fps=15`。先前版本出現人物結果但觀看通道初始化失敗；修正版實機畫面仍待驗證。

最新驗證（2026-10-17）：官方基準版及人物版編譯成功，人物版經使用者授權後以 COM4 燒錄，工具回報 upload success。尚未驗證開機人物偵測、RTSP 畫面與穩定性。詳見 BUILD_VERIFICATION.json、UPLOAD_VERIFICATION.json。

目前程式已包含 SAFE / WARNING / WAITING / STALE 狀態。STALE 或網路中斷不能解讀為 SAFE；事件計數僅維持本次開機，不保存到斷電後。

## 架構與修改原因

沿用 Realtek AmebaPro2 4.0.9-build20250805 的 ObjectDetectionLoop：Camera Channel 0 → H.264 → RTSP；Channel 3 → RGB → YOLOv4-tiny。
人物版只取 person（類別 0）且 score >= 50 的結果，不是重新訓練或人物專用模型。score() 為整數百分制，模型 configThreshold 使用 0～1。

觀看串流改為 640×360、15 FPS、約 768 Kibit/s，以降低原先 1080p/30 FPS 的觀看負載；不保證解決斷線。推論輸入保留 576×320、10 FPS，不能當成實測推論率。

背景 callback 篩選人物並複製到容量為一的 FreeRTOS queue；loop() 只讀已完成的快照，繪製人物框、分數和 PERSON / NO_PERSON / WAITING / STALE 狀態。最多保存 14 個人物框，超出時顯示截斷標記。新結果可覆蓋舊結果，未承諾逐幀處理。沒有結果超過 3 秒顯示 STALE，不當成無人。

框座標為正規化值，顯示時乘上輸出寬高並限制在畫面內。尚待實機確認跨通道視野與對齊。

## 本機帳密

WiFiCredentials.h 僅本機使用，已由 .gitignore 排除；不要上傳含帳密的韌體或打包整個資料夾。新下載專案時，複製 WiFiCredentials.example.h 為 WiFiCredentials.h，再填入自己的熱點資料。

## 編譯

從 C:\Users\vow19\Documents\Arduino 執行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\hw2\IntrusionAlertPrototype\build.ps1
```

Core：realtek:AmebaPro2 4.0.9-build20250805；FQBN：realtek:AmebaPro2:Ameba_AMB82-MINI。
JXF37 / Flash model / Auto Upload Disable / Erase Disable / FCS Disable / NN logs Disable。

建置使用 ../.amb82/portable 既有副本；輸出在 ../.amb82/intrusion-build，紀錄在 ../.amb82/intrusion-logs。不與手勢版共用 build 和紀錄，但 SDK 工具中間產物仍共用，不可同時編譯兩專案。每次燒錄前須重新核對工具目錄中的映像與對應 build 映像雜湊，不能直接沿用其他專案燒錄指令。

本腳本只編譯，不燒錄。實際編譯結果見 BUILD_VERIFICATION.json；實機測試結果另記，不由編譯成功推定。

## 整合版燒錄後的實機驗證（待正常開機與測試）

1. 開啟監視器，等待「連接 COM4 中」後確認 UART_DOWNLOAD 已放開，只按一下 RESET：

```powershell
arduino-cli monitor -p COM4 --config baudrate=115200
```

2. 確認開機標記 `INTRUSION_WEB_V1`、`VIDEO_CONFIG: 640x360 fps=15`，並看到 Wi-Fi、RTSP URL 及 `WEB URL`。
3. 電腦與板子連同一網路，以 VLC 開啟當次輸出的 `rtsp://IP:port`，確認畫面持續更新。
4. 開啟 `http://<板子當次 IP>/`，確認快照、狀態、人物數與事件數會更新；斷網或資料過期時不能仍顯示有效 SAFE。
5. 先無人，再讓人物完整進入 ROI，確認底部中心點、OSD/Serial 的 SAFE→WARNING、事件數加一及 LED；持續停留不應重複計數。
6. 人物離開 ROI 並等待釋放確認後，再進入一次，確認恢復 SAFE 並只增加一次事件；另測短暫漏偵測、多人和超出畫面的邊界情況。
7. 連續觀看至少 2 分鐘，再測關閉/重開 VLC 和網頁。記錄卡頓、`ENC Queue full`、重連、LED 極性及框/ROI 對齊；不要把模型設定 FPS 當成實測值。
8. STALE、影像過期或 Wi-Fi 中斷都不代表安全；記錄任何狀態、影像或 LED 不一致。

## 官方功能與新增項目

官方已有模型推論、人物類別、類別過濾、RTSP、框與分數、OSD 繪字。本原型相對官方範例新增可調 ROI 與底部中心點判斷、具連續新推論影格確認與短暫漏偵測容忍的事件狀態機、重複觸發抑制/事件計數，以及 LED 警示與網頁狀態呈現。人物模型、基本偵測、RTSP、人物框與 OSD 是沿用官方能力，不列為自行開發成果。上述自訂功能已完成程式與桌面測試，仍須板上實測後才能宣稱硬體驗證完成。

## 網頁影像查核

本機 SDK 根目錄：%LOCALAPPDATA%/Arduino15/packages/realtek/hardware/AmebaPro2/4.0.9-build20250805。

- libraries/Multimedia/examples/CaptureJPEG/HTTPDisplayJPEG：WiFiServer(80)、Camera.getImage()、image/jpeg 單張影像。
- libraries/Multimedia/examples/CaptureJPEG/HTTPDisplayJPEGContinuous：multipart/x-mixed-replace 連續 JPEG（MJPEG），官方註解指定 Firefox 測試。其他瀏覽器尚未驗證。
- libraries/NeuralNetwork/examples/ObjectDetectionSaveSDCard/SaveAsJPEG：Channel 0 H.264、Channel 1 JPEG、Channel 3 RGB 同時配置，並為 RTSP/JPEG 設定 OSD。此處只借鏡通道配置，後續網頁不需 SD 卡。

整合方案：保留 RTSP，另使用 JPEG 通道、獨立擷取任務與有界 HTTP socket 服務，網頁輪詢 `/status.json` 及 `/snapshot.jpg`。HTTP 請求大小、等待時間、JPEG 緩衝區均有上限，避免慢客戶端直接阻塞狀態主迴圈。網頁在資料或影像過期時遮蔽舊畫面與狀態。
程式已整合並通過編譯及模擬網頁行為測試；JPEG 通道 OSD 同步、網頁實際載入、效能、斷線重連與長時間穩定性仍待硬體/瀏覽器驗證。

### 網頁歷史區更新

影像下方新增「歷史入侵紀錄」，每次輪詢自動更新，最新事件排在前面，顯示事件編號、停留秒數、進行中／已結束及推論中斷標記。歷史不疊在攝影機影像上。原有 CSV 下載保留；更新失敗時明確標示上次取得的紀錄。新增網頁歷史排序、空紀錄及時長顯示測試通過。

## 參考圖儀表板（2026-10-22）

網頁改為深色雙欄卡片：區域狀態、本次開機事件數、警戒區內人數、最近一次入侵。下方表格顯示最近 10 筆事件的編號、進入／離開時間、事件期間最多區內人數、停留分秒；進行中事件不填造離開時間。即時影像、警報聲、CSV 下載保留在下方。

區內人數由每個有效人物框底部中心點是否落在原 ROI 計算，在最多 14 個顯示框截斷前統計。事件峰值從確認進入起統計，確認離開後保存；不是人物身分追蹤，也不是總人次。

板上沒有新增 RTC 或 NTP：顯示時間由瀏覽器的電腦時鐘與板子開機毫秒數估算，有網路延遲誤差，電腦時鐘必須正確。滑鼠停留在時間欄可看含日期時間。CSV 仍保留原始開機毫秒數，新增 peak_persons 欄位。開機計時回繞超過一週期的超長歷史無法單靠 32 位時間還原日期。

本版已通過 Core 4.0.9 編譯、21 項桌面 C++ 邏輯測試及網頁測試（包含最多人數、最近 10 筆、時間欄位、空紀錄）。以本機 Edge 無頭瀏覽器檢查版面，截圖使用明確標記的示意資料，非實機偵測證據。本版尚未燒錄／實機驗證。

## 持續警笛更新

取代每事件三短音：網頁載入即嘗試啟用 AudioContext；若瀏覽器阻擋，點一下頁面或音效按鈕即可再次嘗試，不申請相機或麥克風權限。以 650/1250 Hz 高低音持續交替，僅於新鮮 WARNING 狀態播放。短暫漏偵測但仍維持 WARNING 時繼續；SAFE、狀態過期、暫停更新、離開頁面或靜音時停止。停止聲音不代表偵測已安全；依畫面狀態判斷。頁面背景節流與系統音量仍影響實際播放。

只修改 WebPage.h 與網頁測試，板上 ROI、事件計時與歷史邏輯不變。編譯與網頁測試通過。此次燒錄嘗試 COM4 open fail，尚未將持續警笛版上傳，舊版仍為先前成功燒錄版本。

## 2026-10-24：監測異常與事件照片（最新候選版）

本節優先於舊版紀錄。未將「無人物」當成鏡頭遮擋。網頁會檢查推論資料年齡與序號、JPEG 擷取年齡、下載／解碼成功時間；異常時主卡片顯示「監測異常」，影像遮罩和連線欄顯示原因，不繼續顯示 SAFE。手動暫停也明示監測暫停。JPEG/網路故障不會停止板子原有入侵判斷。

遮擋採瀏覽器端啟發式影像品質分析，不是訓練的新模型：影像中央區域縮為 32×18，平均亮度 <18 且標準差 <12，或標準差 <3，連續 5 秒提示疑似遮擋／過暗／缺乏細節；亮度平均絕對差 <0.05 持續 30 秒提示疑似凍結。3 張有細節及變化的影格可恢復。參數集中 WebPage.h 的 HEALTH。完全靜止、低光、純色場景可誤報；部分遮擋、彩色圖案遮擋或 OSD 變動可漏報，不能宣稱可辨識所有遮擋。網頁沒開啟時不執行內容分析，板上推論與照片保存仍可運作。需要實際遮擋、光線與長時間測試調整。

確認入侵時，板子複製目前最近且有效的 JPEG 到固定 8 格 RAM 暫存。每格最多 128 KiB，共增加約 1 MiB 照片資料記憶體。網頁沒開也保存；滿額循環覆蓋，斷電／重啟清除。文字歷史仍保留 32 次，照片僅保留最近 8 次的嘗試，兩者容量不同。/events.json 提供 event、entered_ms、image_ms、bytes、offset_ms；/event/<事件編號>-<入侵開機毫秒>.jpg 提供對應影像。網頁顯示事件編號、換算時間、影像相對入侵的毫秒偏差與下載連結。

照片是入侵確認當下最近快照，不保證 AI 同幀；影像擷取完成時間與入侵確認時間最多差 1.5 秒。沒有有效影像或鎖逾時會記錄 Serial EVENT_PHOTO_UNAVAILABLE，沒有照片不能解讀為事件沒有發生；照片 metadata bytes=0 表示保存失敗。網頁下載時照片若已覆蓋，會明確提示。無 SD 卡、無雲端、無磁碟自動持久化；下載到電腦後才可在斷電後保留。

修改：AlertConfig.h（容量）、EventPhotoPolicy.h（有效時間與大小）、WebPreview.cpp/.h（有界照片、HTTP、JPEG 心跳）、IntrusionAlertPrototype.ino（確認事件時保存）、WebPage.h（異常、內容分析、照片區）、tests。未修改 SDK、原手勢專案或帳密。

驗證：22 項 C++ 測試及網頁模擬測試通過，包含時間回繞、JPEG 大小與年齡、遮擋與恢復、凍結、推論心跳、照片編號與失敗狀態。這些不是攝影機實測結果。

實機驗收（待燒錄後執行）：
1. 正常畫面無人應 SAFE；人物進入為 WARNING，歷史與照片編號相同，下載後能打開 JPEG。
2. 用不透光物遮住鏡頭至少 8 秒，應顯示監測異常／疑似遮擋；移開後數張正常影格恢復。另測低光、白紙、部分遮擋並記錄誤報／漏報。
3. 網頁斷網應在狀態期限後顯示異常，不顯示 SAFE；重連恢復。推論停止須以受控停更測試或模擬驗證，不能用手離開畫面替代。
4. 靜止畫面 30 秒以上，確認是否誤報凍結；真凍結與相機噪聲差異需實測。
5. 完成 10 次進出，核對最近 8 次照片及 10 筆文字紀錄；較早照片應被覆蓋，不能對應錯事件。
6. 關閉網頁再進入 ROI，重開網頁仍可見照片；下載後重啟板子，板上紀錄清除但電腦檔案仍在。
7. 同時開啟 RTSP/網頁至少 5 分鐘，觀察記憶體、HTTP 反應與影像負載。不可在通電時拔攝影機排線來製造故障。

## 2026-10-29：事件後影像修正

實機照片曾顯示 `offset_ms=-560` 與 `-121`，證明舊邏輯複製的是確認事件前的最新 JPEG，畫面甚至可能仍顯示 SAFE。新版不再立即複製舊影像：確認入侵後建立 pending 紀錄，略過當時可能已在擷取中的一張，再保存下一輪完成的 JPEG。因此成功照片的 offset 應為正值，通常約 +0.8～+1.8 秒；受 JPEG 擷取時間及系統負載影響，不保證固定延遲。

網頁在等待期間顯示「等待確認入侵後的新影像」。超過 3 秒沒有新影像則標記逾時／失敗，不拿舊照片替代。新事件在上一張仍 pending 時發生，舊 pending 會標記失敗，以保持事件與照片一對一。序號比較與等待時間使用可處理 32 位回繞的運算。

桌面測試及 AmebaPro2 4.0.9 編譯通過；此版尚未燒錄及實機確認。實機應至少重新進入 3 次，確認 offset 全為正值、照片顯示 WARNING 或事件後現場、事件編號不交錯；另遮住／中斷 JPEG 驗證 3 秒後標記失敗。
