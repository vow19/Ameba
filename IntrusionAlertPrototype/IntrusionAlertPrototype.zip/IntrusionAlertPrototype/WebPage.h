#pragma once
// 自含網頁，無 CDN；核心判斷在板子上，瀏覽器只顯示資料。
static const char WEB_PAGE[] = R"HTML(<!doctype html>
<html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>危險區域入侵提醒器</title><style>
:root{font-family:system-ui,sans-serif;color:#edf4fa;background:#101a28}body{max-width:1000px;margin:auto;padding:24px}h1{font-size:26px;margin-bottom:8px}p{color:#bdcbdc;line-height:1.6}.cards{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}.card{background:#1c2a3e;padding:16px;border-radius:12px;flex:1;min-width:150px}.value{display:block;font-size:28px;font-weight:700;margin-top:8px}#state{color:#ffd777}.frame{position:relative;background:#060c14;aspect-ratio:16/9;border:1px solid #42516a;border-radius:12px;overflow:hidden}img{width:100%;height:100%;object-fit:contain}#cover{position:absolute;inset:0;display:grid;place-items:center;background:#101a28e8;font-size:20px;text-align:center;padding:18px}button,a{background:#b8e3ff;color:#071c2e;border:0;border-radius:7px;padding:10px 16px;font:inherit;cursor:pointer}small{display:block;color:#bdcbdc;margin-top:16px}#detail{font-variant-numeric:tabular-nums}
:root{background:#0e1b2b;color:#f3f6fb}body{max-width:1100px;padding:20px}.top,.sectionTitle{display:flex;justify-content:space-between;align-items:center;gap:12px}.top h1{font-size:22px;margin:0}.connection{color:#7ee8ae;font-size:14px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:20px 0 16px}.card,.panel{background:#213148;border-radius:15px}.card{padding:18px;color:#b9c8dc;min-width:0}.value{font-size:26px;color:#f3f6fb;font-variant-numeric:tabular-nums}.panel{padding:18px;margin-bottom:16px}h2{font-size:19px;margin:0}.sectionTitle p{margin:0;font-size:13px}.tableWrap{overflow-x:auto}table{width:100%;border-collapse:collapse;white-space:nowrap;margin-top:12px;text-align:left;font-variant-numeric:tabular-nums}th{font-size:12px;font-weight:500;color:#bac9dc}td{font-size:14px}td,th{padding:10px 8px;border-bottom:1px solid #31425a}tbody tr:last-child td{border:0}.note{font-size:13px;line-height:1.6;margin:10px 0 0;color:#b9c8dc}.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:16px 0}a{text-decoration:none}.frame{margin-top:16px}button,a{font-size:14px}.active{color:#ffb5a4}#historyStatus,#photoStatus{font-size:12px;line-height:1.6;color:#bdcbdc;margin:10px 0 0}.photoGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:14px}.photoGrid article{min-width:0}.photoGrid article>p{font-size:14px;line-height:1.6;margin:8px 0;color:#d7e1ee}.photoGrid img{display:block;border-radius:8px;margin:8px 0}.photoGrid a{display:inline-block;margin-top:4px}@media(max-width:540px){body{padding:12px}.top h1{font-size:18px}.card{padding:14px}.value{font-size:22px}td,th{padding:9px 6px}}
</style><header class="top"><h1>危險區域入侵提醒器</h1><span class="connection" id="connection">● 連線中</span></header>
<div class="cards"><div class="card">區域狀態<strong class="value" id="state">連線中</strong></div><div class="card">本次開機事件數<strong class="value" id="events">—</strong></div><div class="card">警戒區內人數<strong class="value" id="persons">—</strong></div><div class="card">最近一次入侵<strong class="value" id="lastEntry">—</strong></div></div>
<section class="panel"><div class="sectionTitle"><h2>歷史入侵紀錄</h2><p>最近 10 筆</p></div><div class="tableWrap"><table><thead><tr><th>編號</th><th>進入時間</th><th>離開時間</th><th>人數</th><th>停留</th></tr></thead><tbody id="history"><tr><td colspan="5">等待載入</td></tr></tbody></table></div><p class="note">多人事件以警戒區為單位，人數為該事件期間偵測到的最多區內人數。</p><p class="note">時間依電腦時鐘換算（約值，滑鼠停留可看日期）；＊表示推論曾中斷，停留時長不完整。</p><p id="historyStatus">等待載入</p></section>
<section class="panel"><div class="sectionTitle"><h2>即時影像</h2><p>定時快照</p></div>
<div class="frame"><img id="image" alt="攝影機影像"><div id="cover">等待新影像與辨識資料</div></div>
<p id="detail">尚未收到資料</p><button id="toggle">暫停影像</button><small>這是課程原型。畫面採定時快照，與辨識結果可能有時間差；暫停網頁不會停止板子的偵測與 LED。計數不保存於斷電之後。</small>
<p>本次／最近一次停留：<strong id="duration">0.0</strong> 秒 <span id="durationNote"></span></p>
<button id="sound">啟用警報聲</button> <a href="/history.csv" download="intrusion-history.csv">下載歷史 CSV</a>
<small>WARNING 期間持續響警笛，確認離開即停止；狀態過期或暫停更新也會停止聲音，但不代表安全。請保持網頁開啟。歷史保留本次開機最近 32 次完成事件，重開機清除。秒數包含離開確認時間；推論中斷時間不累計，CSV 會標記。</small>
</section>
<section class="panel"><div class="sectionTitle"><h2>事件照片</h2><p>最近 8 次</p></div><p class="note">板上暫存最近 8 次事件，斷電清除。保存確認入侵後的新 JPEG；因快照週期通常會延遲約 0.8～1.8 秒，不是與 AI 同步的精確瞬間。請及時下載。</p><p id="photoStatus">等待照片紀錄</p><div id="photos" class="photoGrid"></div></section>
<script>
let running=true,busy=false,lastImage=0,lastStatus=0,data=null,url=null;
let clockAnchor=null;
const $=id=>document.getElementById(id);
// 影像品質檢查只供監測異常提示；不在瀏覽器執行人物辨識。
const HEALTH={darkMean:18,darkStd:12,flatStd:3,obscuredMs:5000,frozenMs:30000,difference:0.05,recoveryFrames:3};
let healthReason='',badSince=null,stillSince=null,previousPixels=null,goodImages=0,lastAnalyzed=0;
let previousSequence=null,sequenceChangedAt=0,lastUptime=null,photoKey='';
function resetHealth(){healthReason='';badSince=stillSince=null;previousPixels=null;goodImages=0;lastAnalyzed=0;}
function observeStatus(){
 const now=performance.now();
 if(lastUptime!==null && data.uptime_ms<lastUptime){resetHealth();previousSequence=null;photoKey='';$('photos').replaceChildren();}
 lastUptime=data.uptime_ms;
 if(previousSequence!==data.sequence){previousSequence=data.sequence;sequenceChangedAt=now;}
}
function analyzePixels(rgba,now){
 if(lastAnalyzed && now-lastAnalyzed>4000){previousPixels=null;badSince=stillSince=null;}
 lastAnalyzed=now;
 const values=[];let sum=0,sum2=0,delta=0;
 for(let i=0;i<rgba.length;i+=4){const y=0.2126*rgba[i]+0.7152*rgba[i+1]+0.0722*rgba[i+2];values.push(y);sum+=y;sum2+=y*y;}
 const mean=sum/values.length,std=Math.sqrt(Math.max(0,sum2/values.length-mean*mean));
 if(previousPixels&&previousPixels.length===values.length){for(let i=0;i<values.length;i++)delta+=Math.abs(values[i]-previousPixels[i]);delta/=values.length;}else delta=Infinity;
 previousPixels=values;
 const bad=(mean<HEALTH.darkMean&&std<HEALTH.darkStd)||std<HEALTH.flatStd;
 if(bad){if(badSince===null)badSince=now;}else badSince=null;
 if(delta<HEALTH.difference){if(stillSince===null)stillSince=now;}else stillSince=null;
 let reason='';
 if(badSince!==null&&now-badSince>=HEALTH.obscuredMs)reason='疑似鏡頭遮擋、過暗或缺乏影像細節';
 else if(stillSince!==null&&now-stillSince>=HEALTH.frozenMs)reason='疑似畫面凍結（也可能是完全靜止場景）';
 if(reason){healthReason=reason;goodImages=0;}
 else if(!bad&&delta>=HEALTH.difference){if(++goodImages>=HEALTH.recoveryFrames)healthReason='';}else goodImages=0;
}
function analyzeImage(img){
 const c=document.createElement('canvas');c.width=32;c.height=18;
 const ctx=c.getContext('2d',{willReadFrequently:true});
 // 排除上下狀態文字與影像邊緣；ROI 框仍可能干擾，門檻須實測調整。
 ctx.drawImage(img,img.naturalWidth*0.1,img.naturalHeight*0.15,img.naturalWidth*0.8,img.naturalHeight*0.7,0,0,32,18);
 analyzePixels(ctx.getImageData(0,0,32,18).data,performance.now());
}
function monitorIssue(){
 const now=performance.now();
 if(!running)return '監測已暫停（板上判斷仍運作）';
 if(!data||now-lastStatus>3000)return '連線中斷或狀態資料過期';
 if(data.state==='WAITING'||data.state==='STALE'||data.frame_age_ms>3000)return '神經網路推論尚未就緒或已停止更新';
 if(previousSequence!==null&&now-sequenceChangedAt>3000)return '神經網路推論序號停止更新';
 if(data.image_age_ms>3500)return '攝影機 JPEG 擷取停止更新';
 if(now-lastImage>4000)return '影像下載、解碼或更新異常';
 return healthReason;
}
function renderPhotos(items){
 const key=JSON.stringify(items);if(key===photoKey)return;photoKey=key;
 const root=$('photos');root.replaceChildren();
 for(const item of [...items].sort((a,b)=>b.event-a.event)){
  const card=document.createElement('article'),label=document.createElement('p');
  label.textContent='事件 #'+item.event+' · '+eventTime(item.entered_ms).text;
  card.appendChild(label);
  if(item.status==='pending'){
   const note=document.createElement('p');note.textContent='等待確認入侵後的新影像…';card.appendChild(note);
  }else if(item.status==='ready'&&item.bytes>0){
   const path='/event/'+item.event+'-'+item.entered_ms+'.jpg',pic=document.createElement('img'),link=document.createElement('a'),note=document.createElement('p');
   pic.loading='lazy';pic.alt='事件 '+item.event+' 現場照片';pic.style.height='auto';pic.src=path;
   pic.onerror=()=>{note.textContent='照片已被覆蓋或無法取得，請重新整理紀錄';};
   note.textContent='影像相對確認入侵：'+(item.offset_ms>=0?'+':'')+item.offset_ms+' ms';
   link.href=path;link.download='event-'+item.event+'-uptime-'+item.entered_ms+'.jpg';link.textContent='下載照片';
   card.appendChild(pic);card.appendChild(note);card.appendChild(link);
  }else{const note=document.createElement('p');note.textContent='逾時或未取得有效照片（事件仍有紀錄）';card.appendChild(note);}
  root.appendChild(card);
 }
 $('photoStatus').textContent=items.length?'最近事件照片 · 板上暫存，請下載保存':'尚無事件照片';
}
// 聲音權限由瀏覽器決定；不要求相機／麥克風權限。
let audio=null,soundEnabled=false,muted=false,siren=null;
function stopSiren(){
 if(!siren)return;
 const old=siren;siren=null;
 old.tone.stop();old.mod.stop();old.tone.disconnect();old.mod.disconnect();old.depth.disconnect();old.gain.disconnect();
}
function startSiren(){
 if(siren)return;
 const tone=audio.createOscillator(),mod=audio.createOscillator(),depth=audio.createGain(),gain=audio.createGain();
 // 650 / 1250 Hz 每秒切換六次，持續雙音警笛；固定增益避免爆音。
 tone.type='sawtooth';tone.frequency.value=950;
 mod.type='square';mod.frequency.value=3;depth.gain.value=300;gain.gain.value=0.12;
 mod.connect(depth);depth.connect(tone.frequency);tone.connect(gain);gain.connect(audio.destination);
 siren={tone,mod,depth,gain};tone.start();mod.start();
}
function checkAlarm(){
 soundEnabled=!!audio&&audio.state==='running'&&!muted;
 const fresh=running&&data&&performance.now()-lastStatus<=3000;
 if(soundEnabled&&fresh&&data.state==='WARNING'&&data.warning)startSiren();else stopSiren();
 $('sound').textContent=muted?'解除靜音':soundEnabled?'靜音警笛':'點一下啟用警笛（Chrome 可能阻擋自動播放）';
}
function enableAudio(){
 try{
  if(!audio){audio=new (window.AudioContext||window.webkitAudioContext)();audio.onstatechange=checkAlarm;}
  // 自動播放被阻擋時 resume 可能保持 pending；不阻塞影像載入。
  audio.resume().then(checkAlarm).catch(()=>{checkAlarm();});checkAlarm();
 }catch(e){$('sound').textContent='無法啟用警笛，請檢查瀏覽器';}
}
$('sound').onclick=()=>{
 if(soundEnabled){muted=true;checkAlarm();}else{muted=false;enableAudio();}
};
document.addEventListener('pointerdown',e=>{if(e.target!==$('sound')&&!muted&&!soundEnabled)enableAudio();});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target!==$('sound')&&!muted&&!soundEnabled)enableAudio();});
window.addEventListener('pagehide',stopSiren);
async function request(path,format){const c=new AbortController(),t=setTimeout(()=>c.abort(),4000);try{const r=await fetch(path,{cache:'no-store',signal:c.signal});if(!r.ok)throw Error('HTTP '+r.status);return await (format==='json'?r.json():format==='text'?r.text():r.blob());}finally{clearTimeout(t);}}
function render(){checkAlarm();const message=monitorIssue();
$('cover').style.display=message?'grid':'none';$('cover').textContent=message;$('state').textContent=message?'監測異常':data.state;$('state').style.color=message?'#ffd777':data.state==='WARNING'?'#ff8b85':'#7ee8ae';
$('connection').textContent=message?'● '+message:'● 監測中';$('connection').style.color=message?'#ffd777':'#7ee8ae';
if(data){$('duration').textContent=((data.duration_ms||0)/1000).toFixed(1);$('durationNote').textContent=message?'（資料暫不可用）':data.duration_uncertain?'（推論曾中斷，時長不完整）':data.warning?'（計時中）':'（已結束）';$('events').textContent=data.events;$('persons').textContent=message?'—':(data.inside_persons===undefined?'—':data.inside_persons);$('detail').textContent='結果序號 '+data.sequence+' · LED '+(data.led_on?'亮':'滅')+(data.warning?' · 警告鎖存中':'')+(data.truncated?' · 顯示框數已截斷':'');}}
function renderHistory(csv){
 const rows=csv.trim().split(/\r?\n/).slice(1).filter(Boolean).reverse().slice(0,10);
 const body=$('history');body.replaceChildren();
 $('lastEntry').textContent=rows.length?eventTime(rows[0].split(',')[1]).text:'—';
 if(!rows.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=5;td.textContent='尚無入侵紀錄';tr.appendChild(td);body.appendChild(tr);}
 for(const line of rows){
  const [id,start,end,seconds,gap,status,peak]=line.split(',');
  const entry=eventTime(start),exit=eventTime(end),tr=document.createElement('tr');
  const cells=[String(Number(id)).padStart(3,'0'),entry.text,status==='active'?'進行中':exit.text,peak===undefined?'—':String(Number(peak)),durationText(Number(seconds))+(gap==='1'?'＊':'')];
  cells.forEach((value,i)=>{const td=document.createElement('td');td.textContent=value;if(i===1)td.title=entry.full;if(i===2)td.title=exit.full;if(gap==='1'&&i===4)td.title='推論曾中斷，時長不完整';tr.appendChild(td);});
  if(status==='active')tr.className='active';body.appendChild(tr);
 }
 $('historyStatus').textContent='已更新 · 板子保留最近 32 次完成事件；CSV 可下載完整保留紀錄。';
}
function durationText(seconds){const s=Math.max(0,Math.floor(seconds));return s>=60?Math.floor(s/60)+'分'+s%60+'秒':s+'秒';}
function eventTime(ms){
 if(ms===''||!Number.isFinite(Number(ms))||!clockAnchor)return {text:'—',full:''};
 // 無 RTC：以最近一次回應的開機時間和電腦時間換算，不修改板上計時。
 const age=(clockAnchor.uptime-Number(ms))>>>0;
 const d=new Date(clockAnchor.wall-age);
 return {text:d.toLocaleTimeString('zh-TW',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}),full:d.toLocaleString('zh-TW',{hour12:false})+'（電腦時鐘估算）'};
}
let lastExtras=0;
async function cycle(){
 if(busy||!running)return;busy=true;let next=null;
 try{
  data=await request('/status.json','json');lastStatus=performance.now();clockAnchor={uptime:Number(data.uptime_ms),wall:Date.now()};observeStatus();checkAlarm();render();
  const blob=await request('/snapshot.jpg?t='+Date.now(),'blob');next=URL.createObjectURL(blob);
  const probe=await new Promise((resolve,reject)=>{const img=new Image(),timer=setTimeout(()=>reject(Error('影像解碼逾時')),4000);img.onload=()=>{clearTimeout(timer);resolve(img);};img.onerror=()=>{clearTimeout(timer);reject(Error('影像解碼失敗'));};img.src=next;});
  analyzeImage(probe);$('image').src=next;if(url)URL.revokeObjectURL(url);url=next;next=null;lastImage=performance.now();
 }catch(e){$('detail').textContent='等待重連：'+e.message;}
 finally{
  if(next)URL.revokeObjectURL(next);
  // 降低額外 HTTP 負載；即使即時影像失效，也可查看已保存的事件照片。
  if(performance.now()-lastExtras>3000){lastExtras=performance.now();
   try{renderHistory(await request('/history.csv','text'));}catch(e){$('historyStatus').textContent='歷史更新失敗，以下為上次紀錄';}
   try{renderPhotos(await request('/events.json','json'));}catch(e){$('photoStatus').textContent='照片紀錄更新失敗，以下可能是舊紀錄';}
  }
  busy=false;render();
 }
}
$('toggle').onclick=()=>{running=!running;$('toggle').textContent=running?'暫停影像':'恢復影像';if(running){lastImage=lastStatus=0;cycle();}render();};setInterval(cycle,900);setInterval(render,250);enableAudio();cycle();
</script></html>)HTML";
